import React from "react";
import { Link } from "react-router-dom";
import AuthLayout from "../components/AuthLayout";
import Button from "../components/Button";

const Register = () => {
  return (
    <AuthLayout>
      <h2 className="text-2xl font-bold mb-4">注册</h2>
      <input type="text" placeholder="邮箱" className="w-full p-2 border rounded mb-4" />
      <input type="password" placeholder="密码" className="w-full p-2 border rounded mb-4" />
      <Button text="注册" />
      <div className="text-center mt-4">
        <Link to="/login" className="text-blue-500 text-sm">已有账号？登录</Link>
      </div>
    </AuthLayout>
  );
};

export default Register;

import React from "react";
import AuthLayout from "../components/AuthLayout";
import Button from "../components/Button";

const ResetPassword = () => {
  return (
    <AuthLayout>
      <h2 className="text-2xl font-bold mb-4">重置密码</h2>
      <input type="email" placeholder="输入邮箱" className="w-full p-2 border rounded mb-4" />
      <Button text="发送重置链接" />
    </AuthLayout>
  );
};

export default ResetPassword;

'''
1.数据库
mysql -u root -p
password:7994506wzh
SHOW DATABASES;
USE brioche;

2.前端
cd Frontend
cd sdg
npm start

3.后端
cd Backend
python manage.py migrate
python manage.py runserver
'''
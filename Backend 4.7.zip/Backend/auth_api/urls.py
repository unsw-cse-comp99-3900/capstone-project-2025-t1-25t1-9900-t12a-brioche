from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AuthViewSet, GroupViewSet

router = DefaultRouter()
router.register(r"auth", AuthViewSet, basename="auth")
router.register(r"groups", GroupViewSet, basename="group")

urlpatterns = [
    path("", include(router.urls)),
    path("profile/", AuthViewSet.as_view({"get": "profile"}), name="user-profile"),
    path("profile/update/", AuthViewSet.as_view({"put": "update_profile"}), name="update-user-profile"),
]
